#include <iostream>
#include<string>
#include"function.h"

using namespace std;

void Student::setName() {
	cout << "Enter student's name: ";
	getline(cin, name);
}
void Student::setPhone() {
	cout << "Enter student's phone number: ";
	cin >> phone;
}
void Student::setScore() {
	cout << "Enter student's average score: ";
	cin >> aver;
}
bool checkName(string name) {
	if (name.size() > 20)
		return false;
	for (int i = 0; i < name.size(); i++) {
		if (name[i] == ' ')
			continue;
		if ((name[i] >= 'a' && name[i] <= 'z') || (name[i] >= 'A' && name[i] <= 'Z'))
			continue;
		return false;
	}
	return true;
}
bool checkPhone(string phone) {
	if (phone.size() < 9 || phone.size() > 11)
		return false;
	for (int i = 0; i < phone.size(); i++) {
		if (phone[i] >= '0' && phone[i] <= '9')
			continue;
		return false;
	}
	return true;
}
bool checkScore(float score) {
	if (score < 0 || score>10)
		return false;
	return true;
}
void Student::checkInfo() {
	while (!checkName(name)) {
		cout << "Invalid name!\n";
		cin.ignore();
		setName();
	}
	while (!checkPhone(phone)) {
		cout << "Invalid phone number!\n";
		setPhone();
	}
	while (!checkScore(aver)) {
		cout << "Invalid score!\n";
		setScore();
	}
}
void Student::getInfo() {
	cout << "Student's name: " << name << endl;
	cout << "Student's phone number: " << phone << endl;
	cout << "Average score: " << aver << endl;
}