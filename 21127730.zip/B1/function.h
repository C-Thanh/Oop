#pragma once
#include<iostream>
class Student
{
	std::string name;
	std::string phone;
	float aver;
public:
	void setName();
	void setPhone();
	void setScore();
	void checkInfo();
	void getInfo();
};
