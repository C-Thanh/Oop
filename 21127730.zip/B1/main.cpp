#include <iostream>
#include"function.h"

using namespace std;

int main() {
	Student a;
	cout << "Enter student's information: \n";
	a.setName();
	a.setPhone();
	a.setScore();
	a.checkInfo();
	a.getInfo();
}