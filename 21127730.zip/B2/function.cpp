#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include"function.h"

using namespace std;

void Student::setName(std::string n) {
	name = n;
}
void Student::setPhone(std::string p) {
	phone = p;
}
void Student::setScore(float score) {
	aver = score;
}
void Student::getInfo() {
	cout << "Ten hoc sinh: " << name << endl;
	cout << "So dien thoai: " << phone << endl;
	cout << "Diem trung binh: " << aver << endl;
}
bool Student::exist(string n) {
	if (name == n)
		return true;
	return false;
}
bool Student::greaterScore(Student a) {
	if (aver < a.aver)
		return true;
	return false;
}

void lopHoc::setInfo() {
	fstream myFile;
	myFile.open("LopHoc.txt", ios::in);
	if (myFile.fail()) {
		cout << "ERROR!\n";
		exit;
	}
	string n;
	getline(myFile, n);
	string name, phone, score;
	Student a;
	while (!myFile.eof())
	{
		getline(myFile, name);
		getline(myFile, phone);
		getline(myFile, score);
		a.setName(name);
		a.setPhone(phone);
		a.setScore(stof(score));
		Lop.push_back(a);
	}
	myFile.close();
}
void lopHoc::getInfo() {
	for (int i = 0; i < Lop.size(); i++) {
		Lop[i].getInfo();
	}
}
void lopHoc::addNew() {
	Student a;
	cout << "Nhap thong tin hoc sinh can them:\n";
	string name, phone;
	float score;
	/*name = "Cat Thanh";
	phone = "112345678";
	score = 7.4;*/
	cout << "Ten: ";
	getline(cin, name);
	cout << "So dien thoai: ";
	cin >> phone;
	cout << "Diem trung binh: ";
	cin >> score;
	for (int i = 0; i < Lop.size(); i++) {
		if (Lop[i].exist(name)) {
			cout << "Da co hoc sinh trong lop!\n";
			return;
		}
	}
	a.setName(name);
	a.setPhone(phone);
	a.setScore(score);
	Lop.push_back(a);
	cout << "Them thanh cong!\n";
	getInfo();
}
void lopHoc::deleteStudent() {
	string name;
	cin.ignore();
	cout << "Nhap ten hoc sinh can xoa: ";
	getline(cin, name);
	for (int i = 0; i < Lop.size(); i++) {
		if (Lop[i].exist(name)) {
			Lop.erase(Lop.begin() + i);
			cout << "Da xoa!\n";
			getInfo();
			return;
		}
	}
	cout << "Khong co hoc sinh trong lop!\n";
}
void lopHoc::sortScore() {
	for (int i = 0; i < Lop.size() - 1; i++) {
		for (int j = i + 1; j < Lop.size(); j++) {
			if (Lop[i].greaterScore(Lop[j]))
				iter_swap(Lop.begin() + i, Lop.begin() + j);
		}
	}
}