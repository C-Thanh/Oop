#pragma once
#include<iostream>
#include<vector>
using namespace std;
class Student
{
	string name;
	string phone;
	float aver;
public:
	void setName(string name);
	void setPhone(string phone);
	void setScore(float score);
	void getInfo();
	bool exist(string name);
	bool greaterScore(Student);
};
class lopHoc 
{
	vector<Student> Lop;
public:
	void addNew();
	void deleteStudent();
	void sortScore();
	void setInfo();
	void getInfo();
};


