#include<iostream>
#include<vector>
#include"function.h"

using namespace std;
int main() {
	lopHoc a;
	a.setInfo();
	a.getInfo();
	a.addNew();
	a.deleteStudent();
	a.sortScore();
	cout << "Lop sau khi sap xep: \n";
	a.getInfo();
}