#include "ChuyenVien.h"

ChuyenVien::ChuyenVien() :NhanSu() {
	year = 0;
}
ChuyenVien::ChuyenVien(string name, string dob, string ID, vector<string> maDuAn, int year) :NhanSu(name, dob, ID) {
	this->maDuAn = maDuAn;
	this->year = year;
}
ChuyenVien::ChuyenVien(const ChuyenVien& tmp) :NhanSu(tmp) {
	maDuAn = tmp.maDuAn;
	year = tmp.year;
}
void ChuyenVien::input() {
	NhanSu::input();
	cout << "Nhap so ma du an giao duc da hoan thanh: ";
	int num;
	cin >> num;
	string m;
	cin.ignore();
	for (int i = 0;i < num;i++) {
		cout << "Nhap ma du an " << i + 1 << ": ";
		getline(cin, m);
		maDuAn.push_back(m);
	}
	cout << "Nhap so nam kinh nghiem lam viec: ";
	cin >> year;
}
void ChuyenVien::output() {
	NhanSu::output();
	cout << "Cac ma du an giao duc da hoan thanh:\n";
	for (int i = 0;i < maDuAn.size();i++)
		cout << maDuAn[i] << endl;
	cout << "So nam kinh nghiem lam viec: " << year << endl;
}
double ChuyenVien::salary() {
	int count = 0;
	for (int i = 0;i < maDuAn.size();i++) {
		if (maDuAn[i][0] == 'T')
			count++;
	}
	return (year * 4 + count) * 18000;
}
ChuyenVien::~ChuyenVien() {}