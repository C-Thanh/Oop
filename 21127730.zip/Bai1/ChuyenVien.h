#pragma once
#include "NhanSu.h"
#include <vector>

class ChuyenVien :public NhanSu
{
	vector<string> maDuAn;
	int year;
public:
	ChuyenVien();
	ChuyenVien(string name, string dob, string ID, vector<string> maDuAn, int year);
	ChuyenVien(const ChuyenVien& tmp);
	void input();
	void output();
	double salary();
	NhanSu* Clone() { return new ChuyenVien(*this); };
	string subjectName() { return "Chuyen Vien"; };
	~ChuyenVien();
};