#pragma once
#include <vector>
#include "NhanSu.h"

using namespace std;

class GiangVien:public NhanSu
{
	string hocVi;
	string hocHam;
	int year;
	vector<string> subject;
public:
	GiangVien();
	GiangVien(string name, string dob, string ID, string hocVi, string hocHam, int year, vector<string>subject);
	GiangVien(const GiangVien& tmp);
	NhanSu* Clone() {
		return new GiangVien();
	};
	string subjectName() { return "Giang Vien"; };
	void input();
	void output();
	double salary();
	~GiangVien();
};
