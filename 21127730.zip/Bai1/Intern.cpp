#include "Intern.h"

Intern::Intern() {
	time = 0;
}
Intern::Intern(int time, vector<string> project) {
	this->time = time;
	this->project = project;
}
Intern::Intern(const Intern& tmp) {
	time = tmp.time;
	project = tmp.project;
}
double Intern::salary() {
	return (project.size() * 0.1) * 10000;
}
static bool check(string tmp) {
	if (tmp.size() > 3)
		return false;
	if (tmp[0] == 'R') {
		if (tmp[1] >= '0' && tmp[1] <= '9') {
			if (tmp[2] >= '0' && tmp[2] <= '9')
				return true;
		}
	}
	return false;
}
void Intern::input() {
	cout << "Nhap thoi gian thuc tap: ";
	cin >> time;
	string p, choice;
	do
	{
		cout << "Nhap ma du an: ";
		cin.ignore();
		getline(cin, p);
		while (!check(p))
		{
			cout << "Moi nhap lai ma du an: ";
			cin.ignore();
			getline(cin, p);
		}
		project.push_back(p);
		cout << "Tiep tuc nhap? (Y/N)";
		cin >> choice;
	} while (choice == "Y" || choice == "y");
}
void Intern::output() {
	cout << "Thoi gian thuc tap: " << time << " thang.\n";
	cout << "Cac ma du an:\n";
	for (int i = 0;i < project.size();i++)
		cout << project[i] << endl;
}
Intern::~Intern(){}