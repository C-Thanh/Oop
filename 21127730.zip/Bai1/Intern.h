#pragma once
#include <vector>
#include "NhanSu.h"

class Intern: public NhanSu
{
	int time;
	vector<string> project;
public:
	Intern();
	Intern(int time, vector<string> project);
	Intern(const Intern& tmp);
	double salary();
	void input();
	void output();
	NhanSu* Clone() { return new Intern(); };
	string subjectName() { return "Thuc Tap Sinh"; };
	~Intern();
};