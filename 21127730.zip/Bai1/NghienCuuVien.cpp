#include "NghienCuuVien.h"

NghienCuuVien::NghienCuuVien() :NhanSu() {
	year = 0;
}
NghienCuuVien::NghienCuuVien(string name, string dob, string ID, vector<string> maDuAn, int year) :NhanSu(name, dob, ID) {
	this->maDuAn = maDuAn;
	this->year = year;
}
NghienCuuVien::NghienCuuVien(const NghienCuuVien& tmp) :NhanSu(tmp) {
	maDuAn = tmp.maDuAn;
	year = tmp.year;
}
void NghienCuuVien::input() {
	NhanSu::input();
	cout << "Nhap so du an nghien cuu dang tham gia: ";
	int num;
	cin >> num;
	string m;
	cin.ignore();
	for (int i = 0;i < num;i++) {
		cout << "Nhap ma du an " << i + 1 << ": ";
		getline(cin, m);
		maDuAn.push_back(m);
	}
	cout << "Nhap so nam kinh nghiem nghien cuu: ";
	cin >> year;
}
void NghienCuuVien::output() {
	NhanSu::output();
	cout << "Cac ma du an nghien cuu dang tham gia: ";
	for (int i = 0;i < maDuAn.size();i++)
		cout << maDuAn[i] << endl;
}
double NghienCuuVien::salary() {
	int count = 0;
	for (int i = 0;i < maDuAn.size();i++) {
		if (maDuAn[i][0] == 'D') {
			count++;
		}
	}
	return (year * 2 + count) * 20000;
}
NghienCuuVien::~NghienCuuVien(){}