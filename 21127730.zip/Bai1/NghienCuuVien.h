#pragma once
#include "Intern.h"
#include <vector>

class NghienCuuVien : public Intern
{
	vector<string> maDuAn;
	int year;
public:
	NghienCuuVien();
	NghienCuuVien(string name, string dob, string ID, vector<string> maDuAn, int year);
	NghienCuuVien(const NghienCuuVien& tmp);
	void input();
	void output();
	double salary();
	NhanSu* Clone() { return new NghienCuuVien(); };
	string subjectName() { return "Nghien Cuu Vien"; };
	~NghienCuuVien();
};