#pragma once
#include "NhanSu.h"
#include <vector>

class NghienCuuVien : public NhanSu
{
	vector<string> maDuAn;
	int year;
public:
	NghienCuuVien();
	NghienCuuVien(string name, string dob, string ID, vector<string> maDuAn, int year);
	NghienCuuVien(const NghienCuuVien& tmp);
	void input();
	void output();
	double salary();
	~NghienCuuVien();
};