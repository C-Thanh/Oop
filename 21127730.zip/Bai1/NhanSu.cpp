#include "NhanSu.h"

NhanSu::NhanSu(string name, string dob, string ID) {
	this->name = name;
	this->dob = dob;
	this->ID = ID;
}
NhanSu::NhanSu(const NhanSu& tmp) {
	name = tmp.name;
	dob = tmp.dob;
	ID = tmp.ID;
}
istream& operator>>(istream& in, NhanSu*& tmp) {
	cout << "Nhap ten: ";
	in.ignore();
	getline(in, tmp->name);
	cout << "Nhap ngay thang nam sinh: \n";
	int d, m, y;
	cout << "Nhap ngay: ";
	in >> d;
	cout << "Nhap thang: ";
	in >> m;
	cout << "Nhap nam: ";
	in >> y;
	if (y <= 0)
		y = 2000;
	if (m > 12 || m <= 0)
		m = 1;
	if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) {
		if (d > 31 || d <= 0)
			d = 1;
	}
	else if (m == 4 || m == 6 || m == 9 || m == 11) {
		if (d > 30 || d <= 0)
			d = 1;
	}
	else {
		if (y % 4 == 0 && y % 100 != 0 || y % 100 == 0 && y % 400 == 0) {
			if (d > 29 || d <= 0)
				d = 1;
		}
		else
			if (d > 28 || d <= 0)
				d = 1;
	}
	tmp->dob = to_string(d) + "/" + to_string(m) + "/" + to_string(y);
	cout << "Nhap ma so nhan su: ";
	in >> tmp->ID;
	tmp->input();
	return in;
}
ostream& operator<<(ostream& out, NhanSu* tmp) {
	out << "Ten: " << tmp->name << endl;
	out << "Ngay thang nam sinh: " << tmp->dob << endl;
	out << "Ma so nhan su: " << tmp->ID << endl;
	tmp->output();
	return out;
}

void NhanSu::addSubject(NhanSu* tmp) {
	if (tmp == NULL)
		return;
	int pos = -1;
	for (int i = 0;i < typeList.size();i++) {
		NhanSu* s = typeList[i];
		if (s->subjectName() == tmp->subjectName())
			pos = i;
	}
	if (pos == -1)
		typeList.push_back(tmp);
}
NhanSu* NhanSu::newSubject(string name) {
	for (int i = 0;i < typeList.size();i++) {
		NhanSu* s = typeList[i];
		if (s->subjectName() == name) {
			NhanSu* tmp = typeList[i]->Clone();
			cin >> tmp;
			return tmp;
		}
	}
	cout << "ERROR!!!\n";
	return NULL;
}
void NhanSu::deleteAll() {
	for (auto i : typeList)
		delete i;
	typeList.clear();
}
