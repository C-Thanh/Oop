#include "NhanSu.h"

NhanSu::NhanSu() {
	name = "";
	dob = "";
	ID = "";
}
NhanSu::NhanSu(string name, string dob, string ID) {
	this->name = name;
	this->dob = dob;
	this->ID = ID;
}
NhanSu::NhanSu(const NhanSu& tmp) {
	name = tmp.name;
	dob = tmp.dob;
	ID = tmp.ID;
}
void NhanSu::input() {
	cout << "Nhap ten: ";
	getline(cin, name);
	cout << "Nhap ngay thang nam sinh: \n";
	int d, m, y;
	cout << "Nhap ngay: ";
	cin >> d;
	cout << "Nhap thang: ";
	cin >> m;
	cout << "Nhap nam: ";
	cin >> y;
	if (y <= 0)
		y = 2000;
	if (m > 12 || m <= 0)
		m = 1;
	if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) {
		if (d > 31 || d <= 0)
			d = 1;
	}
	else if(m == 4 || m == 6 || m == 9 || m == 11) {
		if (d > 30 || d <= 0)
			d = 1;
	}
	else {
		if (y % 4 == 0 && y % 100 != 0 || y % 100 == 0 && y % 400 == 0) {
			if (d > 29 || d <= 0)
				d = 1;
		}
		else
			if (d > 28 || d <= 0)
				d = 1;
	}
	dob = to_string(d) + "/" + to_string(m) + "/" + to_string(y);
	cout << "Nhap ma so nhan su: ";
	cin >> ID;
}
void NhanSu::output() {
	cout << "Ten: " << name << endl;
	cout << "Ngay thang nam sinh: " << dob << endl;
	cout << "Ma so nhan su: " << ID << endl;
}
NhanSu::~NhanSu(){}
