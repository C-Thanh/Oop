#pragma once
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class NhanSu
{
	static vector<NhanSu*> typeList;
protected:
	string name;
	string dob;
	string ID;
public:
	NhanSu() {};
	NhanSu(string name, string dob, string ID);
	NhanSu(const NhanSu& tmp);
	static void addSubject(NhanSu* tmp);
	static NhanSu* newSubject(string name);
	static void deleteAll();
	virtual void input() = 0;
	virtual void output() = 0;
	virtual double salary() = 0;
	virtual NhanSu* Clone() = 0;
	virtual string subjectName() = 0;
	string subjectID() { return ID; };
	friend istream& operator>>(istream& in, NhanSu*& tmp);
	friend ostream& operator<<(ostream& out, NhanSu* tmp);
	~NhanSu() {};
};
istream& operator>>(istream& in, NhanSu*& tmp);
ostream& operator<<(ostream& out, NhanSu* tmp);
