#pragma once
#include <iostream>
#include <string>

using namespace std;

class NhanSu
{
	string name;
	string dob;
	string ID;
public:
	NhanSu();
	NhanSu(string name, string dob, string ID);
	NhanSu(const NhanSu& tmp);
	void input();
	void output();
	virtual double salary() = 0;
	~NhanSu();
};
