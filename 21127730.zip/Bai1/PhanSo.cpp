#include "PhanSo.h"

PhanSo::PhanSo() {
	setTu(0);
	setMau(1);
}
PhanSo::PhanSo(int tu) {
	setTu(tu);
	setMau(1);
}
PhanSo::PhanSo(int tu, int mau) {
	setTu(tu);
	setMau(mau);
}
PhanSo::PhanSo(const PhanSo& temp) {
	tuso = new int(*temp.tuso);
	mauso = new int(*temp.mauso);
}
void PhanSo::setTu(int tu) {
	tuso = new int(tu);
}
int PhanSo::getTu() {
	return *tuso;
}
void PhanSo::setMau(int mau) {
	mauso = new int(mau);
}
int PhanSo::getMau() {
	return *mauso;
}
int gcd(int a, int b) {
	a = abs(a);
	b = abs(b);
	if (a == b)
		return a;
	else if (a > b)
		return gcd(a - b, b);
	else
		return gcd(a,b-a);
}
PhanSo rutGon(PhanSo& temp) {
	int tu = temp.getTu() / gcd(temp.getTu(), temp.getMau());
	int mau = temp.getMau() / gcd(temp.getTu(), temp.getMau());
	temp.setTu(tu);
	temp.setMau(mau);
	return temp;
}
PhanSo PhanSo::operator+(PhanSo temp) {
	PhanSo res;
	if (mauso == temp.mauso) {
		*res.mauso = *mauso;
		*res.tuso = *tuso + *temp.tuso;
		return rutGon(res);
	}
	*res.mauso = * mauso * *temp.mauso;
	*res.tuso = *tuso * *temp.mauso + *temp.tuso * *mauso;
	return rutGon(res);
}
PhanSo PhanSo::operator-(PhanSo temp) {
	PhanSo res;
	if (mauso == temp.mauso) {
		res.mauso = mauso;
		*res.tuso = *tuso - *temp.tuso;
		return rutGon(res);
	}
	*res.mauso = *mauso * *temp.mauso;
	*res.tuso = *tuso * *temp.mauso - *temp.tuso * *mauso;
	return rutGon(res);
}
PhanSo PhanSo::operator*(PhanSo temp) {
	PhanSo res;
	*res.tuso = *tuso * *temp.tuso;
	*res.mauso = *mauso * *temp.mauso;
	return rutGon(res);
}
PhanSo PhanSo::operator/(PhanSo temp) {
	PhanSo res;
	if (*temp.tuso == 0) {
		*res.tuso = 0;
		*res.mauso = 0;
		return res;
	}
	PhanSo temp1(temp);
	swap(*temp1.tuso, *temp1.mauso);
	*res.tuso = *tuso * *temp1.tuso;
	*res.mauso = *mauso * *temp1.mauso;
	return rutGon(res);
}
ostream& operator<<(ostream& out, PhanSo temp) {
	if (temp.getMau() == 1) {
		out << temp.getTu() << endl;
		return out;
	}
	if (temp.getMau() == 0 && temp.getTu() == 0) {
		out << "Khong the thuc hien phep chia.\n";
		return out;
	}
	out << temp.getTu() << "/" << temp.getMau() << endl;
	return out;
}
istream& operator>>(istream& in, PhanSo& t) {
	cout << "1/ Nhap 1 tham so.\n";
	cout << "2/ Nhap 2 tham so.\n";
	cout << "Chon phuong thuc nhap: ";
	int n;
	cin >> n;
	if (n == 1) {
		int tu;
		cout << "Nhap tu so: ";
		in >> tu;
		t.setTu(tu);
		t.setMau(1);
		return in;
	}
	else if (n == 2) {
		int tu, mau;
		cout << "Nhap tu so: ";
		in >> tu;
		cout << "Nhap mau so: ";
		do
		{
			in >> mau;
			if (mau == 0)
				cout << "Mau khong the bang 0!\n";
		} while (mau==0);
		t.setTu(tu);
		t.setMau(mau);
		return in;
	}
}
void PhanSo::xuat() {
	if (*tuso == 0 && *mauso == 0) {
		cout << "Khong the thuc hien phep chia!\n";
		return;
	}
	cout << (float)getTu()/ (float)getMau() << endl;
}
PhanSo::~PhanSo() 
{
	delete tuso;
	delete mauso;
}