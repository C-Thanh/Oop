#pragma once
#include <iostream>

using namespace std;
class PhanSo
{
	int* tuso;
	int* mauso;
public:
	PhanSo();
	PhanSo(int);
	PhanSo(int, int);
	PhanSo(const PhanSo&);
	void setTu(int);
	int getTu();
	void setMau(int);
	int getMau();
	PhanSo operator+(PhanSo);
	PhanSo operator-(PhanSo);
	PhanSo operator*(PhanSo);
	PhanSo operator/(PhanSo);
	void xuat();
	~PhanSo();
};
istream& operator>>(istream& in, PhanSo&);
ostream& operator<<(ostream& out, PhanSo);

