#include "PhongQuanLy.h"
#include "ChuyenVien.h"
#include "GiangVien.h"
#include "Intern.h"
#include "NghienCuuVien.h"
#include "TroGiang.h"

vector<NhanSu*> NhanSu::typeList;
PhongQuanLy::PhongQuanLy() {
	NhanSu::addSubject(new GiangVien());
	NhanSu::addSubject(new TroGiang());
	NhanSu::addSubject(new NghienCuuVien());
	NhanSu::addSubject(new ChuyenVien());
	NhanSu::addSubject(new Intern());
}
double PhongQuanLy::salaryTotal() {
	double sum = 0;
	for (auto i : sample)
		sum += i->salary();
	return sum;
}
void PhongQuanLy::printAll() {
	for (auto i : sample)
		cout << i;
}
void PhongQuanLy::deleteID() {
	string id;
	cout << "Nhap ma so nhan vien can xoa: ";
	cin >> id;
	for (int i = 0;i < sample.size();i++)
		if (sample[i]->subjectID() == id) {
			sample.erase(sample.begin() + i);
			cout << "Xoa thanh cong!\n";
			return;
		}
	cout << "Khong tim thay nhan su!\n";
}
istream& operator>>(istream& in, PhongQuanLy& tmp) {
	char key;
	int choice;
	do
	{
		system("cls");
		cout << "1/ Giang Vien \n2/ Tro Giang \n3/Thuc tap sinh \n4/ Nghien Cuu Vien \n5/ Chuyen Vien\n";
		cout << "Chon nhan su muon nhap thong tin: ";
		cin >> choice;
		NhanSu* temp = NULL;
		if (choice == 1)
			temp = NhanSu::newSubject("Giang Vien");
		else if (choice == 2)
			temp = NhanSu::newSubject("Tro Giang");
		else if (choice == 3)
			temp = NhanSu::newSubject("Thuc Tap Sinh");
		else if (choice == 4)
			temp = NhanSu::newSubject("Nghien Cuu Vien");
		else if (choice == 5)
			temp = NhanSu::newSubject("Chuyen Vien");
		else
			cout << "ERROR!\n";
		if (temp != NULL)
			tmp.sample.push_back(temp);
		cout << "Tiep tuc nhap (Y/N): ";
		cin >> key;
	} while (key == 'Y' || key == 'y');
	return in;
}
PhongQuanLy::~PhongQuanLy() {
	for (auto i : sample)
		delete i;
	sample.clear();
}
