#pragma once
#include <vector>
#include "NhanSu.h"

class PhongQuanLy 
{
	vector<NhanSu*> sample;
public:
	PhongQuanLy();
	double salaryTotal();
	void printAll();
	void deleteID();
	friend istream& operator>>(istream& in, PhongQuanLy& tmp);
	~PhongQuanLy();
};
istream& operator>>(istream& in, PhongQuanLy& tmp);