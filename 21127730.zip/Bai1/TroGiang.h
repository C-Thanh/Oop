#pragma once
#include "NhanSu.h"

class TroGiang : public NhanSu
{
	int num;
public:
	TroGiang();
	TroGiang(string name, string dob, string ID, int num);
	TroGiang(const TroGiang& tmp);
	void input();
	void output();
	double salary();
	NhanSu* Clone() { return new TroGiang(); };
	string subjectName() { return "Tro Giang"; };
	~TroGiang();
};
