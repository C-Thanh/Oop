#include <iostream>
#include "PhanSo.h"

using namespace std;

int main() {
	PhanSo a;
	cin >> a;
	cout << "Phan so vua nhap la: ";
	cout << a;
	cout << "Phan so vua nhap theo dinh dang thap phan la: ";
	a.xuat();
	cout << "Chon phuong thuc khoi tao phan so thu hai:\n ";
	cout << "1/ Nhap tham so.\n";
	cout << "2/ Sao chep tu phan so vua nhap.\n";
	int n;
	cout << "Chon phuong thuc: ";
	cin >> n;
	PhanSo b;
	if (n == 1) {
		cin >> b;
		cout << "Phan so vua nhap la: ";
		cout << b;
	}
	else if (n == 2) {
		PhanSo temp(a);
		b = temp;
		cout << "Phan so vua sao chep la: ";
		cout << b;
	}
	else {
		cout << "Invalid!\n";
		return 0;
	}
	PhanSo temp;
	cout << "Tong 2 phan so la: ";
	cout << a + b;
	cout << "Hieu 2 phan so la: ";
	cout << a - b;
	cout << "Tich 2 phan so la: ";
	cout << a * b;
	cout << "Thuong 2 phan so la: ";
	cout << a / b;
	return 0;
}