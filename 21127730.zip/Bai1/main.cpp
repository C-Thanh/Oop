#include <iostream>
#include "GiangVien.h"
#include "TroGiang.h"
#include "NghienCuuVien.h"
#include "ChuyenVien.h"
#include "Intern.h"

using namespace std;

int main() {
	vector<GiangVien>  gv;
	vector<TroGiang> tg;
	vector<NghienCuuVien>ncv;
	vector<ChuyenVien> cv;
	vector<Intern> in;
	char choice;
	do
	{
		cout << "1/ Giang Vien.\n";
		cout << "2/ Tro Giang.\n";
		cout << "3/ Nghien Cuu Vien.\n";
		cout << "4/ Chuyen Vien.\n";
		cout << "5/ Thuc tap sinh.\n";
		int c;
		cout << "Chon thong tin nhan su muon nhap: ";
		cin >> c;
		switch (c)
		{
		case 1: {
			GiangVien a;
			cout << "Nhap thong tin cua giang vien: \n";
			cin.ignore();
			a.input();
			gv.push_back(a);
			break;
		}
		case 2: {
			TroGiang a;
			cout << "Nhap thong tin tro giang: \n";
			cin.ignore();
			a.input();
			tg.push_back(a);
			break;
		}
		case 3: {
			NghienCuuVien a;
			cout << "Nhap thong tin nghien cuu vien:\n";
			cin.ignore();
			a.input();
			ncv.push_back(a);
			break;
		}
		case 4: {
			ChuyenVien a;
			cout << "Nhap thong tin chuyen vien:\n";
			cin.ignore();
			a.input();
			cv.push_back(a);
			break;
		}
		case 5: {
			Intern a;
			cout << "Nhap thong tin thuc tap sinh:\n";
			cin.ignore();
			a.input();
			in.push_back(a);
			break;
		}
		default:
			cout << "ERROR!\n";
		}
		cout << "Tiep tuc nhap? (Y/N)";
		cin >> choice;
	} while (choice == 'y' || choice == 'Y');
	double s = 0, g = 0;
	cout << "Thong tin nhan su cua truong: \n";
	cout << "Giang vien: \n";
	for (int i = 0;i < gv.size();i++) {
		gv[i].output();
		s += gv[i].salary();
		if (g < gv[i].salary())
			g = gv[i].salary();
	}
	cout << "Tro giang: \n";
	for (int i = 0;i < tg.size();i++) {
		tg[i].output();
		s += tg[i].salary();
		if (g < tg[i].salary())
			g = tg[i].salary();
	}
	cout << "Nghien cuu vien: \n";
	for (int i = 0;i < ncv.size();i++) {
		ncv[i].output();
		s += ncv[i].salary();
		if (g < ncv[i].salary())
			g = ncv[i].salary();
	}
	cout << "Chuyen vien:\n";
	for (int i = 0;i < cv.size();i++) {
		cv[i].output();
		s += cv[i].salary();
		if (g < cv[i].salary())
			g = cv[i].salary();
	}
	cout << "Thuc tap sinh:\n";
	for (int i = 0;i < in.size();i++) {
		in[i].output();
		s += in[i].salary();
		if (g < in[i].salary())
			g = in[i].salary();
	}
	cout << "Tong luong nhan su: " << s << " dong\n ";
	cout << "Luong cua nhan su cao nhat truong: " << g << " dong\n";
}