#include "Account.h"

void Account::action(int price) {
	money -= price;
}
bool isValid(string tmp, int type) {
	if (type != 1)
		if (tmp.size() < 8)
			return false;
	for (int i = 0;i < tmp.size();i++)
		if (tmp[i] == ' ')
			return false;
	return true;
}
istream& operator>>(istream& in, Account*& tmp) {
	cout << "Nhap username:(khong co khoang trang) ";
	getline(in, tmp->username);
	while (!isValid(tmp->username, 1)) {
		cout << "Username khong hop le. Moi nhap lai: ";
		getline(in, tmp->username);
	}
	cout << "Nhap password(toi thieu 8 ky tu va khong co khoang trang): ";
	getline(in, tmp->password);
	while (!isValid(tmp->password, 2)) {
		cout << "Mat khau khong hop le. Moi nhap lai: ";
		getline(in, tmp->password);
	}
	tmp->input();
	return in;
}
ostream& operator<<(ostream& out, Account* tmp) {
	out << "Username: " << tmp->username << endl;
	out << "Password: " << tmp->password << endl;
	out << "So tien con lai trong tai khoan: " << tmp->money << endl;
	return out;
}

void VIPAccount::input() {
	cout << "Gia cua goi VIP: 100000\n";
	duration = 5;
	setMoney(100000);
}
void VIPAccount::ouput() {
	cout << "Thoi han con lai cua goi VIP: " << duration << " thang.\n";
}
void VIPAccount::action(int p) {
	int m = getMoney();
	m -= p / 2;
	setMoney(m);
}
void VIPAccount::extend() {
	unsigned int m;
	cout << "Nhap so tien nap de gia han goi VIP: ";
	cin >> m;
	m += getMoney();
	setMoney(m);
	while (m < 100000) {
		cout << "Khong du tien de gia han.\n";
		cout << "moi nap them.\nSo tien nap: ";
		cin >> m;
		m += getMoney();
		setMoney(m);
	}
	cout << "Tai khoan da duoc gia han them " << m / 100000 << " thang.\n";
	duration += m / 100000;
	setMoney(m - 100000);
}
void VIPAccount::writeFile() {
	fstream file("Accounts//" + getUsername() + ".txt", ios::app);
	file << " " << duration;
	file.close();
}
VIPAccount::~VIPAccount() {
}