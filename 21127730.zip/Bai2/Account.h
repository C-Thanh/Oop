#pragma once
#include "Song.h"

class Account
{
	string username;
	string password;
	vector<Song*> list;
	int money;

public:
	Account() {};
	virtual void input() { money = 50000; };
	virtual void output() {};
	virtual bool isVIP() { return false; };
	virtual void action(int a);
	virtual void writeFile() {};
	int getMoney() { return money; };
	void setMoney(int m) { money = m; };
	void setUsername(string name) { username = name; };
	string getUsername() { return username; };
	void setPassword(string pass) { password = pass; };
	friend istream& operator>>(istream& in, Account*& tmp);
	friend ostream& operator<<(ostream& out, Account* tmp);
	~Account() {};
};
istream& operator>>(istream& in, Account*& tmp);
ostream& operator<<(ostream& out, Account* tmp);

class VIPAccount : public Account
{
	int duration;
public:
	VIPAccount() {};
	void input();
	void ouput();
	bool isVIP() { return true; };
	bool isExpired() { return duration == 0; };
	void action(int p);
	void extend();
	void writeFile();
	void setDuration(int d) { duration = d; };
	~VIPAccount();
};