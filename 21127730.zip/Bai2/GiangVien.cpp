#include "GiangVien.h"

GiangVien::GiangVien() :NhanSu() {
	hocHam = "";
	hocVi = "";
	year = 0;
}
GiangVien::GiangVien(string name, string dob, string ID, string hocVi, string hocHam, int year, vector<string>subject) :
	NhanSu(name, dob, ID)
{
	this->hocVi = hocVi;
	this->hocHam = hocHam;
	this->subject = subject;
	this->year = year;
}
GiangVien::GiangVien(const GiangVien& tmp) : NhanSu(tmp) {
	hocVi = tmp.hocVi;
	hocHam = tmp.hocHam;
	subject = tmp.subject;
	year = tmp.year;
}
void GiangVien::input() {
	cout << "Nhap hoc vi: ";
	cin.ignore();
	getline(cin, hocVi);
	cout << "Nhap hoc ham: ";
	cin.ignore();
	getline(cin, hocHam);
	cout << "Nhap so nam giang day: ";
	cin >> year;
	int num;
	cout << "Nhap so mon giang day: ";
	cin >> num;
	string s;
	cin.ignore();
	for (int i = 0;i < num;i++) {
		cout << "Nhap ten mon hoc: ";
		getline(cin, s);
		subject.push_back(s);
	}
}
void GiangVien::output() {
	cout << "Hoc ham: " << hocHam << endl;
	cout << "Hoc vi: " << hocVi << endl;
	cout << "So nam giang day: " << year << endl;
	cout << "Cac mon giang day: ";
	for (int i = 0;i < subject.size();i++) {
		cout << subject[i] << endl;
	}
}
double GiangVien::salary() {
	return (subject.size() * year * 0.12) * 20000;
}
GiangVien::~GiangVien() {}