#include "Hero.h"

Skill::Skill() {
	skillName = "";
	skillLevel = 0;
}
Skill::Skill(string name) {
	skillName = name;
	skillLevel = 0;
}
Skill::Skill(unsigned int level) {
	skillName = "";
	skillLevel = level;
}
Skill::Skill(string name, unsigned int level) {
	skillName = name;
	skillLevel = level;
}
Skill::Skill(const Skill& temp) {
	skillName = temp.skillName;
	skillLevel = temp.skillLevel;
}
void Skill::setName(string name) {
	skillName = name;
}
string Skill::getName() {
	return skillName;
}
void Skill::setLevel(unsigned int level) {
	skillLevel = level;
}
int Skill::getLevel() {
	return skillLevel;
}
istream& operator>>(istream& in, Skill& tmp) {
	cout << "Input name: ";
	cin.ignore();
	string name;
	getline(in, name);
	tmp.setName(name);
	cout << "Input level required: ";
	unsigned int level;
	cin >> level;
	tmp.setLevel(level);
	return in;
}
ostream& operator<<(ostream& out, Skill tmp) {
	out << "Skill: " << tmp.getName() << endl;
	out << "Level required: " << tmp.getLevel() << endl;
	return out;
}
Skill::~Skill() {};

Hero::Hero() {
	heroName = "";
	heroHealth = 0;
	heroMana = 0;
	heroLevel = 0;
	skillList = {};
}
Hero::Hero(string name) {
	heroName = name;
	heroHealth = 0;
	heroMana = 0;
	heroLevel = 0;
	skillList = {};
}
Hero::Hero(unsigned int value, int mode) {
	if (mode == 1) {
		heroName = "";
		heroHealth = value;
		heroMana = 0;
		heroLevel = 0;
		skillList = {};
	}
	else if (mode == 2) {
		heroName = "";
		heroHealth = 0;
		heroMana = value;
		heroLevel = 0;
		skillList = {};
	}
	else {
		heroName = "";
		heroHealth = 0;
		heroMana = 0;
		heroLevel = value;
		skillList = {};
	}
}

Hero::Hero(vector<Skill*>list) {
	heroName = "";
	heroHealth = 0;
	heroMana = 0;
	skillList = list;
	heroLevel = skillList[skillList.size() - 1]->getLevel();
}
Hero::Hero(string name, unsigned int value, int mode) {
	if (mode == 1) {
		heroName = name;
		heroHealth = value;
		heroMana = 0;
		heroLevel = 0;
	}
	else if (mode == 2) {
		heroName = name;
		heroHealth = 0;
		heroMana = value;
		heroLevel = 0;
	}
	else {
		heroName = name;
		heroHealth = 0;
		heroMana = 0;
		heroLevel = value;
	}
	
}
Hero::Hero(string name, vector<Skill*> tmp) {
	heroName = name;
	heroHealth = 0;
	heroMana = 0;
	heroLevel = 0;
	skillList = tmp;
}
Hero::Hero(unsigned int val1, unsigned int val2, int mode) {
	if (mode == 1) {
		heroName = "";
		heroHealth = val1;
		heroMana = val2;
		heroLevel = 0;
	}
	else if (mode == 2) {
		heroName = "";
		heroHealth = val1;
		heroMana = 0;
		heroLevel = val2;
	}
	else {
		heroName = "";
		heroHealth = 0;
		heroMana = val1;
		heroLevel = val2;
	}
}
Hero::Hero(string name, unsigned int val, vector<Skill*> tmp, int mode) {
	if (mode == 1) {
		heroName = name;
		heroHealth = val;
		heroMana = 0;
		heroLevel = 0;
		skillList = tmp;
	}
	else if (mode == 2) {
		heroName = name;
		heroHealth = 0;
		heroMana = val;
		heroLevel = 0;
		skillList = tmp;
	}
	else {
		heroName = name;
		heroHealth = 0;
		heroMana = 0;
		heroLevel = val;
		skillList = tmp;
	}
}
Hero::Hero(string name, unsigned int mana, unsigned int health, unsigned int level, vector<Skill*>list) {
	heroName = name;
	heroHealth = health;
	heroMana = mana;
	heroLevel = level;
	skillList = list;
}
void Hero::setName(string name) {
	heroName = name;
}
string Hero::getName() {
	return heroName;
}
void Hero::setHealth(unsigned int health) {
	heroHealth = health;
}
int Hero::getHealth() {
	return heroHealth;
}
void Hero::setMana(unsigned int mana) {
	heroMana = mana;
}
int Hero::getMana() {
	return heroMana;
}
void Hero::setLevel(unsigned int level) {
	heroLevel = level;
}
int Hero::getLevel() {
	return heroLevel;
}
void Hero::addSkill(Skill* temp) {
	skillList.push_back(temp);
}
void Hero::setSkill(vector<Skill*>list) {
	skillList = list;
}
vector<Skill*> Hero::getSkill() {
	return skillList;
}
void Hero::possibleSkills() {
	for (int i = 0;i < skillList.size();i++) {
		if (skillList[i]->getLevel() > heroLevel)
			return;
		cout << skillList[i]->getName() << "\t";
	}
}
void Hero::deleteSkill(int n) {
	if (n >= skillList.size()) {
		skillList.clear();
		return;
	}
	skillList.erase(skillList.end() - 1 - n, skillList.end());
}
Hero::~Hero() { }

istream& operator>>(istream& in, Hero& temp) {
	cout << "Input name: ";
	string name;
	getline(in, name);
	temp.setName(name);
	unsigned int health, mana, level;
	cout << "Input health: ";
	in >> health;
	cout << "Input mana: ";
	in >> mana;
	cout << "Input level: ";
	in >> level;
	temp.setHealth(health);
	temp.setMana(mana);
	temp.setLevel(level);
	int num;
	cout << "How many skill you want to input: ";
	cin >> num;
	vector<Skill*> list;
	for (int i = 0;i < num;i++) {
		Skill tmp;
		cout << "How many attribute for the skill you want to input? (1 or 2): ";
		int m;
		cin >> m;
		if (m == 1) {
			cout << "What do you want to input?\n 1/ Skill name\n 2/Skill level required\n";
			int mode;
			cin >> mode;
			if (mode == 1) {
				string name;
				cout << "Input skill name: ";
				cin.ignore();
				getline(cin, name);
				tmp.setName(name);
				list.push_back(&tmp);
			}
			else {
				unsigned int level;
				cout << "Input level: ";
				cin >> level;
				tmp.setLevel(level);
				list.push_back(&tmp);
			}
		}
		else {
			cin >> tmp;
			list.push_back(&tmp);
		}
	}
	Hero tmp(list);
	temp.setSkill(tmp.getSkill());
	return in;
}
ostream& operator<<(ostream& out, Hero& temp) {
	out << "Name: " << temp.getName() << endl;
	out << "Health: " << temp.getHealth() << endl;
	out << "Mana: " << temp.getMana() << endl;
	out << "Level: " << temp.getLevel() << endl;
	out << "Skills: ";
	for (int i = 0; i < temp.getSkill().size();i++) {
		out << temp.getSkill()[i];
	}
	out << endl;
	return out;
}