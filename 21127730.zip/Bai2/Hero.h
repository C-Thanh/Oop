#pragma once
#include <iostream>
#include <vector>
#include <string>
#include<algorithm>
using namespace std;

class Skill
{
	string skillName;
	unsigned int skillLevel;
public:
	Skill();
	Skill(string);
	Skill(unsigned int);
	Skill(string, unsigned int);
	Skill(const Skill&);
	void setName(string);
	string getName();
	void setLevel(unsigned int);
	int getLevel();
	~Skill();
};
istream& operator>>(istream& in, Skill& tmp);
ostream& operator<<(ostream& out, Skill tmp);
class Hero
{
	string heroName;
	unsigned int heroHealth;
	unsigned int heroMana;
	unsigned int heroLevel;
	vector<Skill*> skillList;
public:
	Hero();
	Hero(string);
	Hero(unsigned int, int mode );
	Hero(vector<Skill*>);
	Hero(string, unsigned int, int mode );
	Hero(string, vector<Skill*>);
	Hero(unsigned int, unsigned int, int mode );
	Hero(string, unsigned int, vector<Skill*>, int mode);
	Hero(string, unsigned int, unsigned int, unsigned int, vector<Skill*>);
	void setName(string);
	string getName();
	void setHealth(unsigned int);
	int getHealth();
	void setMana(unsigned int);
	int getMana();
	void setLevel(unsigned int);
	int getLevel();
	void addSkill(Skill* temp);
	void setSkill(vector<Skill*>);
	void possibleSkills();
	void deleteSkill(int n);
	vector<Skill*> getSkill();
	~Hero();
};
istream& operator>>(istream& in, Hero&);
ostream& operator<<(ostream& out, Hero&);
