#include "HinhChuNhat.h"
HinhChuNhat::HinhChuNhat() {
	length = width = 0;
}
HinhChuNhat::HinhChuNhat(int width, int length) {
	this->width = width;
	this->length = length;
}
HinhChuNhat::HinhChuNhat(const HinhChuNhat& tmp) {
	width = tmp.width;
	length = tmp.length;
}
int HinhChuNhat::Area() {
	return width * length;
}
int HinhChuNhat::Perimeter() {
	return (width + length) * 2;
}
HinhChuNhat::~HinhChuNhat(){}
istream& operator>>(istream& in, HinhChuNhat& tmp) {
	cout << "Nhap chieu dai: ";
	in >> tmp.length;
	cout << "Nhap chieu rong: ";
	in >> tmp.width;
	return in;
}
ostream& operator<<(ostream& out, HinhChuNhat& tmp) {
	out << "Chieu dai: " << tmp.length << endl;
	out << "Chieu rong: " << tmp.width << endl;
	return out;
}