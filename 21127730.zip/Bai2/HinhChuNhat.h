#pragma once
#include <iostream>

using namespace std;

class HinhChuNhat
{
	int width;
	int length;
public:
	HinhChuNhat();
	HinhChuNhat(int width, int length);
	HinhChuNhat(const HinhChuNhat& tmp);
	int Area();
	int Perimeter();
	friend istream& operator>>(istream& in, HinhChuNhat& tmp);
	friend ostream& operator<<(ostream& out, HinhChuNhat& tmp);
	~HinhChuNhat();
};
istream& operator>>(istream& in, HinhChuNhat& tmp);
ostream& operator<<(ostream& out, HinhChuNhat& tmp);