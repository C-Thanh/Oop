#include "HinhVuong.h"

HinhVuong::HinhVuong() :HinhChuNhat(){}
HinhVuong::HinhVuong(int a):HinhChuNhat(a,a){}
HinhVuong::HinhVuong(const HinhVuong& tmp) : HinhChuNhat(tmp){}
HinhVuong::~HinhVuong() {}
istream& operator>>(istream& in, HinhVuong& tmp) {
	cout << "Nhap do dai canh: ";
	int l;
	in >> l;
	HinhVuong s(l);
	tmp = s;
	return in;
}
ostream& operator<<(ostream& out, HinhVuong& tmp) {
	HinhChuNhat temp(tmp);
	out << temp;
	return out;
}