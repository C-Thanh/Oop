#pragma once
#include "HinhChuNhat.h"

class HinhVuong : public HinhChuNhat
{
public:
	HinhVuong();
	HinhVuong(int a);
	HinhVuong(const HinhVuong& tmp);
	friend istream& operator>>(istream& in, HinhVuong& tmp);
	friend ostream& operator<<(ostream& out, HinhVuong& tmp);
	~HinhVuong();
};
istream& operator>>(istream& in, HinhVuong& tmp);
ostream& operator<<(ostream& out, HinhVuong& tmp);