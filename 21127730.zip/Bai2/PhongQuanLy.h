#pragma once
#include <vector>
#include "NhanSu.h"

class PhongQuanLy
{
	static PhongQuanLy* instance;
	PhongQuanLy();
	vector<NhanSu*> sample;
public:
	static PhongQuanLy* getInstance();
	double salaryTotal();
	void printAll();
	void deleteID();
	friend istream& operator>>(istream& in, PhongQuanLy& tmp);
	static void deleteInstance();
	~PhongQuanLy();
};
istream& operator>>(istream& in, PhongQuanLy& tmp);