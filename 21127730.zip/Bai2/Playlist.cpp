﻿#include "Playlist.h"

Playlist::Playlist() {
	fstream file("Music/MusicList.txt", ios::in);
	while (!file.eof())
	{
		string temp;
		getline(file, temp, '\n');
		readFile(temp);
	}
	file.close();
}
void Playlist::writeFile() {
	//luu lai thong tin tai khoan sau khi nghe nhac xong
}
bool Playlist::readFile(string name) {
	fstream file("Music/" + name + ".txt", ios::in);
	if (file.fail()) {
		file.close();
		return false;
	}
	string tmp;
	file >> tmp;
	Song* song;
	if (tmp == "Copyright") {
		song = new CopyrightSong();
		int p;
		file >> p;
		song->setPrice(p);
	}
	else {
		song = new Song();
		song->setPrice(0);
	}
	song->setName(name);
	int n;
	string m;
	getline(file, m);
	song->setSinger(m);
	file >> n;
	song->setYear(n);
	file >> n;
	song->setListen(n);
	getline(file, m);
	m.erase(0, 1);
	song->setType(m);
	vector<string>lyric;
	while (!file.eof()) {
		getline(file, m);
		lyric.push_back(m);
	}
	song->setLyric(lyric);
	list.push_back(song);
	file.close();
	return true;
}
bool isExist(string tmp) {
	fstream file("Accounts//" + tmp + ".txt", ios::in);
	if (file.fail())
		return false;
	file.close();
	return true;
}
void Playlist::login() {
	int choice;
	cout << "1/ Dang nhap \n2/ Dang ky\n";
	cin >> choice;
	cin.ignore();
	if (choice == 1) {
		string username;
		cout << "Nhap username: ";
		getline(cin, username);
		while (!isExist(username))
		{
			cout << "Tai khoan khong ton tai!\nMoi nhap lai username: ";
			getline(cin, username);
		}
		fstream file("Accounts//" + username + ".txt", ios::in);
		string pass;
		file >> pass;
		cout << "Nhap password: ";
		string password;
		getline(cin, password);
		while (password!=pass)
		{
			cout << "Sai mat khau!\nMoi nhap lai: ";
			getline(cin, password);
		}
		string type;
		file >> type;
		if (type == "VIP") {
			VIPAccount* tmp = new VIPAccount();
			tmp->setUsername(username);
			tmp->setPassword(password);
			int m;
			file >> m;
			tmp->setMoney(m);
			file >> m;
			tmp->setDuration(m);
			user = tmp;
		}
		else {
			user = new Account();
			user->setUsername(username);
			user->setPassword(password);
			int m;
			file >> m;
			user->setMoney(m);
		}
		file.close();
	}
	else {
		cout << "1.Tai khoan thuong\n2.Tai khoan VIP\n";
		cin >> choice;
		cin.ignore();
		if (choice == 1)
		{
			user = new Account();
			cin >> user;
		}
		else
		{
			user = new VIPAccount();
			cin >> user;
		}
	}
}
void Playlist::play() {
	//choi nhac
}
void Playlist::addNew() {
	cout << "Chon laoi bai hat muon them.";
	cout << "1/ Bai hat thuong\n2/ Bai hat co ban quyen\n";
	int n;
	cin >> n;
	cin.ignore();
	if (n == 1)
	{
		Song* s = new Song();
		cin >> s;
		list.push_back(s);
	}
	else
	{
		Song* s = new CopyrightSong();
		cin >> s;
		list.push_back(s);
	}
	cout << "Them thanh cong\n";
}
void Playlist::top5() {
	// sap xep danh sach bai hat theo luot nghe de lay top 5
}
void Playlist::printAll() {
	// xuat tat ca bai hat dang co trong playlist
}
void Playlist::playSong(string name) {
	// choi 1 bai hat bat ky do nguoi dung nhap vao
}
void Playlist::listType() {
	// loc ra cac bai hat theo tung the loai nhac
}
bool Playlist::isExist(string name) {
	//kiem tra xem ten bai hat vua nhap vao co ton tai trong playlist khong
	return true;
}
void Playlist::loadCash() {
	//nap them tien vao tai khoan
}
void Playlist::addSong() {
	// them bai hat vao playlist
}
void Playlist::playAll() {
	// mo tat ca bai hat trong playlist
}
void Playlist::recommendSong() {
	//dua ra cac bai hat goi y theo the loai
}
istream& operator>>(istream& in, Playlist& tmp) {
	return in;
}
ostream& operator<<(ostream& out, Playlist tmp) {
	return out;
}
Playlist::~Playlist() {
	delete user;
	for (auto i : list)
		delete i;
	list.clear();
}