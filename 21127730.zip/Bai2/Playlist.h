#pragma once
#include "Song.h"
#include "Account.h"

class Playlist
{
	Account* user;
	vector<Song*> list;
public:
	Playlist() ;
	void writeFile();
	bool readFile(string name);
	void login();
	void play();
	void addNew();
	void top5();
	void printAll();
	void playSong(string name);
	void listType();
	bool isExist(string name);
	void printInfo() { cout << user; };
	void loadCash();
	void addSong();
	void playAll();
	void recommendSong();
	friend istream& operator>>(istream& in, Playlist& tmp);
	friend ostream& operator<<(ostream& out, Playlist tmp);
	~Playlist();
};
istream& operator>>(istream& in, Playlist& tmp);
ostream& operator<<(ostream& out, Playlist tmp);