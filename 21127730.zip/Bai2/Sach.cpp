#include "Sach.h"

Sach::Sach() {
	title = "";
	author = "";
	status = 0;
}
Sach::Sach(string title, string author, bool status) {
	this->title = title;
	this->author = author;
	this->status = status;
}
Sach::Sach(const Sach& tmp) {
	title = tmp.title;
	author = tmp.author;
	status = tmp.status;
}
bool Sach::check(string title) {
	if (title == this->title)
		return true;
	return false;
}
bool Sach::getStatus() {
	return status;
}
void Sach::setStatus(bool status) {
	this->status = status;
}
Sach::~Sach() {}
istream& operator>>(istream& in, Sach& tmp) {
	cout << "Nhap ten sach: ";
	in.ignore();
	getline(in, tmp.title);
	cout << "Nhap ten tac gia: ";
	in.ignore();
	getline(in, tmp.author);
	cout << "Sach da duoc muon? (Y/N)";
	string choice;
	cin >> choice;
	if (choice == "Y" || choice == "y")
		tmp.status = 1;
	else
		tmp.status = 0;
	return in;
}
ostream& operator<<(ostream& out, Sach& tmp) {
	if (tmp.title==" " && tmp.author == "") {
		out << "ERROR!\n";
	}
	else {
		out << "Ten sach: " << tmp.title << endl;
		out << "Tac gia: " << tmp.author << endl;
		if (tmp.status)
			cout << "Sach da duoc muon.\n";
		else
			cout << "Sach chua duoc muon.\n";
	}
	return out;
}