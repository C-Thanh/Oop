#pragma once
#include <iostream>
#include <string>
using namespace std;

class Sach
{
	string title;
	string author;
	bool status;
public:
	Sach();
	Sach(string name, string author, bool status);
	Sach(const Sach& tmp);
	friend istream& operator>>(istream& in, Sach& tmp);
	friend ostream& operator<<(ostream& out, Sach& tmp);
	bool check(string title);
	bool getStatus();
	void setStatus(bool status);
	~Sach();
};
istream& operator>>(istream& in, Sach& tmp);
ostream& operator<<(ostream& out, Sach& tmp);