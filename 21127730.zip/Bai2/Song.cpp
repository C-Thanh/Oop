#include "Song.h"

istream& operator>>(istream& in, Song*& tmp) {
	cout << "Nhap ten bai hat: ";
	getline(in, tmp->name);
	cout << "Nhap ten ca sy: ";
	getline(in, tmp->singer);
	cout << "Chon the loai:\n1/ Viet Nam\n2/ Au My\n";
	int type;
	do
	{
		cin >> type;
		if (type == 1)
			tmp->type = "Viet Nam";
		else if (type == 2)
			tmp->type = "Au My";
		else
			cout << "Moi nhap lai: ";
	} while (type != 1 && type != 2);
	cout << "Nhap nam san xuat: ";
	cin >> tmp->year;
	cout << "Nhap so luot nghe: ";
	cin >> tmp->listen;
	tmp->input();
	cout << "Nhap loi bai hat:\n";
	char k;
	string s;
	do
	{
		getline(in, s);
		cout << "Dong thu " << tmp->lyric.size() + 1 << " : ";
		getline(in, s);
		tmp->lyric.push_back(s);
		cout << "Tiep tuc nhap? (Y/N) ";
		cin >> k;
	} while (k == 'y' || 'Y');
	return in;
}
ostream& operator<<(ostream& out, Song* tmp) {
	out << "Ten bai hat: " << tmp->name << endl;
	out << "Ca sy: " << tmp->singer << endl;
	out << "Nam san xuat: " << tmp->year << endl;
	out << "Luot nghe: " << tmp->listen << endl;
	out << "The loai: " << tmp->type << endl;
	tmp->output();
	return out;
}

void CopyrightSong::input() {
	cout << "Tien cho moi lan nghe: ";
	unsigned int p;
	cin >> p;
	setPrice(p);
}
void CopyrightSong::output() {
	cout << "Tien nghe 1 luot: " << getPrice() << endl;
}