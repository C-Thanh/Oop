#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

class Song
{
	string name;
	string singer;
	string type;
	unsigned int year;
	unsigned int listen;
	unsigned int price;
	vector<string> lyric;
public:
	Song() {};
	virtual void input() {};
	virtual void output() {};
	int getPrice() { return price; };
	void setPrice(int p) { price = p; };
	void setName(string name) { this->name = name; };
	void setSinger(string name) { singer = name; };
	void setYear(int y) { year = y; };
	void setListen(int l) { listen = l; };
	void setType(string t) { type = t; };
	void setLyric(vector<string> l) { lyric = l; };
	string getName() { return name; };
	string getSinger() { return singer; };
	int getYear() { return year; };
	int getListen() { return listen; };
	string getType() { return type; };
	vector<string> getLyric() { return lyric; };
	friend istream& operator>>(istream& in, Song*& tmp);
	friend ostream& operator<<(ostream& out, Song* tmp);
	~Song() {};
};
istream& operator>>(istream& in, Song*& tmp);
ostream& operator<<(ostream& out, Song* tmp);

class CopyrightSong : public Song
{
public:
	CopyrightSong() {};
	void input();
	void output();
	~CopyrightSong() {};
};