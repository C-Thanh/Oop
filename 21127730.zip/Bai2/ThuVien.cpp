#include "ThuVien.h"

ThuVien::ThuVien() {}
ThuVien::ThuVien(vector<Sach> list) {
	this->list = list;
}
ThuVien::ThuVien(const ThuVien& tmp) {
	list = tmp.list;
}
Sach ThuVien::search() {
	string name;
	cout << "Nhap ten sach can tim: ";
	cin.ignore();
	getline(cin, name);
	for (int i = 0;i < list.size();i++) {
		if (list[i].check(name))
			return list[i];
	}
	Sach tmp;
	return tmp;
}
void ThuVien::add() {
	string title, author;
	cout << "Nhap ten sach: ";
	cin.ignore();
	getline(cin, title);
	cout << "Nhap ten tac gia: ";
	cin.ignore();
	getline(cin, author);
	for (int i = 0;i < list.size();i++) {
		if (list[i].check(title)) {
			cout << "Sach da ton tai!\n";
			return;
		}
	}
	bool status;
	cout << "Sach da duoc muon? (Y/N)";
	string choice;
	cin >> choice;
	if (choice == "Y" || choice == "y")
		status = 1;
	else
		status = 0;
	Sach tmp(title, author, status);
	list.push_back(tmp);
}
void ThuVien::remove() {
	string title;
	cout << "Nhap ten sach can xoa: ";
	cin.ignore();
	getline(cin, title);
	for (int i = 0;i < list.size();i++) {
		if (list[i].check(title)) {
			list.erase(list.begin() + i);
			return;
		}
	}
	cout << "ERROR!\n";
}
void ThuVien::borrow() {
	string title;
	cout << "Nhap ten sach can muon: ";
	cin.ignore();
	getline(cin, title);
	for (int i = 0;i < list.size();i++) {
		if (list[i].check(title)) {
			if (!list[i].getStatus())
				list[i].setStatus(1);
			else
				cout << "Sach da duoc muon.\n";
			return;
		}
	}
	cout << "Thu vien khong co cuon sach nay!\n";
}
void ThuVien::returnBook() {
	string title;
	cout << "Nhap ten sach muon tra: ";
	cin.ignore();
	getline(cin, title);
	for (int i = 0;i < list.size();i++) {
		if (list[i].check(title)) {
			if (list[i].getStatus())
				list[i].setStatus(0);
			else
				cout << "Sach chua duoc muon.\n";
			return;
		}
	}
	cout << "Thu vien khong co cuon sach nay!\n";
}
ThuVien::~ThuVien(){}
istream& operator>>(istream& in, ThuVien& tmp) {
	string choice;
	do
	{
		cout << "Nhap thong tin sach: \n";
		Sach temp;
		in >> temp;
		tmp.list.push_back(temp);
		cout << "Tiep tuc nhap?(Y/N) ";
		in >> choice;
	} while (choice == "Y"||choice=="y");
	return in;
}
ostream& operator<<(ostream& out, ThuVien& tmp) {
	out << "Thong tin sach co trong thu vien: \n";
	for (int i = 0;i < tmp.list.size();i++)
		out << tmp.list[i];
	return out;
}