#pragma once
#include "Sach.h"
#include <vector>

class ThuVien
{
	vector<Sach> list;
public:
	ThuVien();
	ThuVien(vector<Sach> list);
	ThuVien(const ThuVien& tmp);
	Sach search();
	void add();
	void remove();
	void borrow();
	void returnBook();
	friend istream& operator>>(istream& in, ThuVien& tmp);
	friend ostream& operator<<(ostream& out, ThuVien& tmp);
	~ThuVien();
};
istream& operator>>(istream& in, ThuVien& tmp);
ostream& operator<<(ostream& out, ThuVien& tmp);