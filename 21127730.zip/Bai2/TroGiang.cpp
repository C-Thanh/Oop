#include "TroGiang.h"

TroGiang::TroGiang() :NhanSu() {
	num = 0;
}
TroGiang::TroGiang(string name, string dob, string ID, int num) :NhanSu(name, dob, ID) {
	this->num = num;
}
TroGiang::TroGiang(const TroGiang& tmp) :NhanSu(tmp) {
	num = tmp.num;
}
void TroGiang::input() {
	cout << "Nhap so mon tro giang: ";
	cin >> num;
}
void TroGiang::output() {
	cout << "So mon tro giang: " << num << endl;
}
double TroGiang::salary() {
	return (num * 0.3) * 18000;
}
TroGiang::~TroGiang() {}