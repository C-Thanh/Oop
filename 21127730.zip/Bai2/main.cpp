#include<iostream>
#include"Hero.h"

using namespace std;

int main() {
	int n;
	Hero a, a1;
	cin >> a1;
	cout << "First hero:\n";
	cout << a1;
	cout << "How do you want to construct new Hero?\n 1/ Input attribute\n 2/ Copy\n";
	int c;
	cin >> c;
	if(c==1) {
		cout << "How many attribute input for your hero?(1,2,3 or 5)";
		cin >> n;
		if (n == 1) {
			cout << "Which attribute?\n 1/Name \n 2/Health \n 3/Mana \n 4/Level\n 5/Skill list\n";
			int choice;
			cin >> choice;
			switch (choice)
			{
			case 1: {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				Hero tmp(name);
				a.setName(tmp.getName());
				break;
			}
			case 2: {
				unsigned int health;
				cout << "Input health: ";
				cin >> health;
				Hero tmp(health, 1);
				a.setHealth(tmp.getHealth());
				break;
			}
			case 3: {
				unsigned int mana;
				cout << "Input mana: ";
				cin >> mana;
				Hero tmp(mana, 2);
				a.setMana(tmp.getMana());
				break;
			}
			case 4: {
				unsigned int level;
				cout << "Input level: ";
				cin >> level;
				Hero tmp(level, 3);
				a.setLevel(tmp.getLevel());
				break;
			}
			case 5: {
				int num;
				cout << "How many skill you want to input: ";
				cin >> num;
				vector<Skill*> list;
				for (int i = 0;i < num;i++) {
					Skill tmp;
					cout << "How many attribute for the skill you want to input? (1 or 2)";
					int m;
					cin >> m;
					if (m == 1) {
						cout << "What do you want to input?\n 1/ Skill name\n 2/Skill level required";
						int mode;
						cin >> mode;
						if (mode == 1) {
							string name;
							cout << "Input skill name: ";
							cin.ignore();
							getline(cin, name);
							tmp.setName(name);
							list.push_back(&tmp);
						}
						else {
							unsigned int level;
							cout << "Input level: ";
							cin >> level;
							tmp.setLevel(level);
							list.push_back(&tmp);
						}
					}
					else {
						cin >> tmp;
						list.push_back(&tmp);
					}
				}
				Hero tmp(list);
				a.setSkill(tmp.getSkill());
				break;
			}
			default:
				cout << "Invalid choice!\n";
				return 0;
			}
		}
		else if (n == 2) {
			cout << "Which two attribute?\n 1/ Name and health\n 2/ Name and mana\n 3/Name and level\n 4/ Name and skill\n 5/ Health and mana\n 6/ Health and level\n 7/ Mana and level";
			int choice;
			cin >> choice;
			switch (choice)
			{
			case 1: {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				unsigned int val;
				cout << "Input health: ";
				cin >> val;
				Hero tmp(name, val, 1);
				a = tmp;
				break;
			}
			case 2: {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				unsigned int val;
				cout << "Input mana: ";
				cin >> val;
				Hero tmp(name, val, 2);
				a = tmp;
				break;
			}
			case 3: {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				unsigned int val;
				cout << "Input level: ";
				cin >> val;
				Hero tmp(name, val, 3);
				a = tmp;
				break;
			}
			case 4: {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				int num;
				cout << "How many skill you want to input: ";
				cin >> num;
				vector<Skill*> list;
				for (int i = 0;i < num;i++) {
					Skill tmp;
					cout << "How many attribute for the skill you want to input? (1 or 2)";
					int m;
					cin >> m;
					if (m == 1) {
						cout << "What do you want to input?\n 1/ Skill name\n 2/Skill level required";
						int mode;
						cin >> mode;
						if (mode == 1) {
							string name;
							cout << "Input skill name: ";
							cin.ignore();
							getline(cin, name);
							tmp.setName(name);
							list.push_back(&tmp);
						}
						else {
							unsigned int level;
							cout << "Input level: ";
							cin >> level;
							tmp.setLevel(level);
							list.push_back(&tmp);
						}
					}
					else {
						cin >> tmp;
						list.push_back(&tmp);
					}
				}
				Hero tmp(name, list);
				a = tmp;
				break;
			}
			case 5: {
				unsigned int val1, val2;
				cout << "Input health: ";
				cin >> val1;
				cout << "Input mana: ";
				cin >> val2;
				Hero tmp(val1, val2, 1);
				a = tmp;
				break;
			}
			case 6: {
				unsigned int val1, val2;
				cout << "Input health: ";
				cin >> val1;
				cout << "Input level: ";
				cin >> val2;
				Hero tmp(val1, val2, 2);
				a = tmp;
				break;
			}
			case 7: {
				unsigned int val1, val2;
				cout << "Input mana: ";
				cin >> val1;
				cout << "Input level: ";
				cin >> val2;
				Hero tmp(val1, val2, 3);
				a = tmp;
				break;
			}
			default:
				cout << "Invalid choice!\n";
				return 0;
			}
		}
		else if (n == 3) {
			cout << "Which three?\n1/Name, health and skill\n 2/Name, mana and skill\n 3/Name, level and skill";
			int choice;
			cin >> choice;
			if (choice == 1) {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				unsigned int val;
				cout << "Input health: ";
				cin >> val;
				int num;
				cout << "How many skill you want to input: ";
				cin >> num;
				vector<Skill*> list;
				for (int i = 0;i < num;i++) {
					Skill tmp;
					cout << "How many attribute for the skill you want to input? (1 or 2)";
					int m;
					cin >> m;
					if (m == 1) {
						cout << "What do you want to input?\n 1/ Skill name\n 2/Skill level required";
						int mode;
						cin >> mode;
						if (mode == 1) {
							string name;
							cout << "Input skill name: ";
							cin.ignore();
							getline(cin, name);
							tmp.setName(name);
							list.push_back(&tmp);
						}
						else {
							unsigned int level;
							cout << "Input level: ";
							cin >> level;
							tmp.setLevel(level);
							list.push_back(&tmp);
						}
					}
					else {
						cin >> tmp;
						list.push_back(&tmp);
					}
				}
				Hero tmp(name, val, list, 1);
				a = tmp;
			}
			else if (choice == 2) {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				unsigned int val;
				cout << "Input mana: ";
				cin >> val;
				int num;
				cout << "How many skill you want to input: ";
				cin >> num;
				vector<Skill*> list;
				for (int i = 0;i < num;i++) {
					Skill tmp;
					cout << "How many attribute for the skill you want to input? (1 or 2)";
					int m;
					cin >> m;
					if (m == 1) {
						cout << "What do you want to input?\n 1/ Skill name\n 2/Skill level required";
						int mode;
						cin >> mode;
						if (mode == 1) {
							string name;
							cout << "Input skill name: ";
							cin.ignore();
							getline(cin, name);
							tmp.setName(name);
							list.push_back(&tmp);
						}
						else {
							unsigned int level;
							cout << "Input level: ";
							cin >> level;
							tmp.setLevel(level);
							list.push_back(&tmp);
						}
					}
					else {
						cin >> tmp;
						list.push_back(&tmp);
					}
				}
				Hero tmp(name, val, list, 2);
				a = tmp;
			}
			else if (choice == 3) {
				string name;
				cout << "Input name: ";
				cin.ignore();
				getline(cin, name);
				unsigned int val;
				cout << "Input level: ";
				cin >> val;
				int num;
				cout << "How many skill you want to input: ";
				cin >> num;
				vector<Skill*> list;
				for (int i = 0;i < num;i++) {
					Skill tmp;
					cout << "How many attribute for the skill you want to input? (1 or 2)";
					int m;
					cin >> m;
					if (m == 1) {
						cout << "What do you want to input?\n 1/ Skill name\n 2/Skill level required";
						int mode;
						cin >> mode;
						if (mode == 1) {
							string name;
							cout << "Input skill name: ";
							cin.ignore();
							getline(cin, name);
							tmp.setName(name);
							list.push_back(&tmp);
						}
						else {
							unsigned int level;
							cout << "Input level: ";
							cin >> level;
							tmp.setLevel(level);
							list.push_back(&tmp);
						}
					}
					else {
						cin >> tmp;
						list.push_back(&tmp);
					}
				}
				sort(list.begin(), list.end());
				while (val < list[list.size() - 1]->getLevel()) {
					cout << "Invalid level!\n Input level: ";
					cin >> val;
				}
				Hero tmp(name, val, list, 1);
				a = tmp;
			}
			else {
				cout << "Invalid choice!\n";
				return 0;
			}
		}
		else if (n == 5) {
			string name;
			cout << "Input name: ";
			cin.ignore();
			getline(cin, name);
			unsigned int health, mana, level;
			cout << "Input health: ";
			cin >> health;
			cout << "Input mana: ";
			cin >> mana;
			cout << "Input level: ";
			cin >> level;
			int num;
			cout << "How many skill you want to input: ";
			cin >> num;
			vector<Skill*> list;
			for (int i = 0;i < num;i++) {
				Skill tmp;
				cout << "How many attribute for the skill you want to input? (1 or 2)";
				int m;
				cin >> m;
				if (m == 1) {
					cout << "What do you want to input?\n 1/ Skill name\n 2/Skill level required";
					int mode;
					cin >> mode;
					if (mode == 1) {
						string name;
						cout << "Input skill name: ";
						cin.ignore();
						getline(cin, name);
						tmp.setName(name);
						list.push_back(&tmp);
					}
					else {
						unsigned int level;
						cout << "Input level: ";
						cin >> level;
						tmp.setLevel(level);
						list.push_back(&tmp);
					}
				}
				else {
					cin >> tmp;
					list.push_back(&tmp);
				}
			}
			sort(list.begin(), list.end());
			while (level < list[list.size() - 1]->getLevel()) {
				cout << "Invalid level!\n Input level: ";
				cin >> level;
			}
			Hero tmp(name, health, mana, level, list);
			a = tmp;
		}
		else {
			cout << "Invalid choice!\n";
			return 0;
		}
	}
	else if(c==2) {
		Hero tmp(a1);
		a = tmp;
	}
	else{
		cout << "Invalid choice!\n";
		return 0;
	}
	cout << "Second hero: \n";
	cout << a;
	cout << "Skills that the first Hero can learn: ";
	a1.possibleSkills();
	cout << endl;
	cout << "Skills that the second Hero can learn: ";
	a.possibleSkills();
	cout << endl;
	cout << "Which hero to delete skill?";
	int choice;
	cin >> choice;
	if (choice == 1) {
		int n;
		cout << "How many skill needed to delete?";
		cin >> n;
		a1.deleteSkill(n);
		cout << "After deleted:\n" << a1;
	}
	else if (choice == 2) {
		int n;
		cout << "How many skill needed to delete?";
		cin >> n;
		a.deleteSkill(n);
		cout << "After deleted:\n" << a;
	}
	else
		cout << "Invalid choice!\n";
}