#include <iostream>
#include "Song.h"
#include "Account.h"
#include "Playlist.h"

using namespace std;

int main() {
	Playlist p;
	p.login();
	system("cls");
	while (true)
	{
		cout << "1/ Nhac theo the loai\n2/ Top 5\n3/ Choi nhac\n4/ Them nhac\n5/ Thong tin tai khoan\n6/ Nap tien\n7/ Danh sach bai hat\n8/ Them vao playlist\n9/ Choi ca playlist\n10/ Thoat\n";
		int choice;
		cout << "Nhap lua chon: ";
		cin >> choice;
		switch (choice)
		{
		case 1: {
			system("cls");
			p.listType();
			break;
		}
		case 2: {
			system("cls");
			p.top5();
			break;
		}
		case 3: {
			system("cls");
			string name;
			getline(cin, name);
			cout << "Nhap vao ten bai hat: ";
			getline(cin, name);
			if (!p.isExist(name))
				cout << "Bai hat khong ton tai !\n";
			else
				p.playSong(name);
			break;
		}
		case 4: {
			system("cls");
			p.addNew();
			break;
		}
		case 5: {
			system("cls");
			p.printInfo();
			break;
		}
		case 6: {
			system("cls");
			p.loadCash();
			break;
		}
		case 7: {
			system("cls");
			p.printAll();
			break;
		}
		case 8: {
			system("cls");
			cin.ignore();
			p.addSong();
			break;
		}
		default:
			break;
		}
	}
	p.writeFile();
}