#include<iostream>
#include "HinhVuong.h"
#include "ThuVien.h"

using namespace std;

int main() {
	int c;
	cout << "Chon lop muon thao tac: \n";
	cout << "1/ Hinh vuong - Hinh chu nhat.\n";
	cout << "2/ Thu vien -  Sach.\n";
	cin >> c;
	if (c == 1) {
		HinhChuNhat r;
		HinhVuong s;
		cout << "Nhap thong tin hinh chu nhat:\n";
		cin >> r;
		cout << r;
		cout << "Chu vi hinh chu nhat: " << r.Perimeter() << endl;
		cout << "Dien tich hinh chu nhat: " << r.Area() << endl;
		cout << "Nhap thong tin hinh vuong: \n";
		cin >> s;
		cout << s;
		cout << "Chu vi hinh vuong: " << s.Perimeter() << endl;
		cout << "Dien tich hinh vuong: " << s.Area() << endl;
	}
	else {
		Sach b1;
		cout << "Nhap thong tin sach: \n";
		cin >> b1;
		cout << b1;
		cout << "Chon cach nhap cuon thu hai:\n";
		cout << "1/ Nhap thong tin.\n";
		cout << "2/ Copy lai thong tin cuon vua nhap.\n";
		int choice;
		cout << "Chon cach nhap: ";
		cin >> choice;
		Sach b2;
		if (choice == 1) {
			string title, author;
			bool status;
			cout << "Nhap ten sach: ";
			cin.ignore();
			getline(cin, title);
			cout << "Nhap ten tac gia: ";
			cin.ignore();
			getline(cin, author);
			cout << "Sach da duoc muon? (Y/N)";
			string choice;
			cin >> choice;
			if (choice == "Y" || choice == "y")
				status = 1;
			else
				status = 0;
			Sach tmp(title, author, status);
			b2 = tmp;
		}
		else {
			Sach tmp(b1);
			b2 = tmp;
		}
		cout << b2;
		ThuVien lib;
		cout << "Nhap thong tin sach trong thu vien:\n";
		cin >> lib;
		cout << lib;
		cout << "1/ Them sach vao thu vien.\n";
		cout << "2/ Bo bot sach.\n";
		cout << "3/ Tim sach.\n";
		cout << "4/ Muon sach.\n";
		cout << "5/ Tra sach.\n";
		do
		{
			cout << "Nhap lua chon: ";
			cin >> choice;
			if (choice == 1) {
				lib.add();
				cout << lib;
			}
			else if (choice == 2) {
				lib.remove();
				cout << lib;
			}
			else if (choice == 3) {
				Sach tmp(lib.search());
				cout << "Thong tin sach can tim: " << tmp;
			}
			else if (choice == 4) {
				lib.borrow();
				cout << lib;
			}
			else if (choice == 5) {
				lib.returnBook();
				cout << lib;
			}
			else
				cout << "ERROR!\n";
		} while (choice >= 1 && choice <= 5);
	}
}