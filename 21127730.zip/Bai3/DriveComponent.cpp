#include "DriveComponent.h"

ostream& operator<<(ostream& out, DriveComponent* tmp) {
	out << "Ten: " << tmp->name << endl;
	out << "Dung luong: " << tmp->size << endl;
	return out;
}