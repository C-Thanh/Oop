#pragma once
#include <iostream>

using namespace std;

class DriveComponent
{
protected:
	string name;
	float size;
public:
	DriveComponent() { size = 0; };
	virtual string getName() = 0;
	virtual float getSize() = 0;
	virtual void addNew(DriveComponent* tmp) {};
	virtual void remove(DriveComponent* tmp) {};
	friend ostream& operator<<(ostream& out, DriveComponent* tmp);
	virtual ~DriveComponent() {};
};
ostream& operator<<(ostream& out, DriveComponent* tmp);