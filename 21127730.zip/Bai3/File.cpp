#include "File.h"

File::File(string name, float size) {
	this->name = name;
	this->size = size;
}
string File::getName() {
	return name;
}
float File::getSize() {
	return size;
}