#pragma once
#include "DriveComponent.h"

class File : public DriveComponent
{
public:
	File(string name, float size);
	string getName();
	float getSize();
	~File() {};
};