#include "Folder.h"

string Folder::getName() {
	return name;
}
float Folder::getSize() {
	float total = 0;
	for (auto i : components)
		total += i->getSize();
	return total;
}
void Folder::addNew(DriveComponent* tmp) {
	for (auto i : components) {
		if (i->getName() == tmp->getName()) {
			cout << "Da ton tai!\n";
			return;
		}
	}
	components.push_back(tmp);
}
ostream& operator<<(ostream& out, Folder* tmp) {
	for (auto i : tmp->components)
		out << i;
	return out;
}
Folder::~Folder() {
	for (auto i : components)
		delete i;
	components.clear();
}