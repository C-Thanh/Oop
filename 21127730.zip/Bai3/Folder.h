#pragma once
#include <vector>
#include "DriveComponent.h"

class Folder : public DriveComponent
{
	vector<DriveComponent*> components;
public:
	Folder(string name) { this->name = name; };
	string getName();
	float getSize();
	void addNew(DriveComponent* tmp);
	friend ostream& operator<<(ostream& out, Folder* tmp);
	~Folder();
};
ostream& operator<<(ostream& out, Folder* tmp);