#include <iostream>
#include <string>
#include "Folder.h"
#include "File.h"

using namespace std;

int main() {
	vector<Folder*> driver;
	string name;
	char key;
	int choice;
	do
	{
		cout << "1/ Them folder.\n2/ Them file.\n3/ Xoa file";
		cout << "Chon lenh: ";
		cin >> choice;
		if (choice == 1) {
			system("cls");
			bool flag = 1;
			cout << "Nhap ten thu muc muon them: ";
			cin >> name;
			for (auto i : driver)
				if (i->getName() == name) {
					cout << "Thu muc da ton tai!\n";
					flag = 0;
					break;
				}
			if (flag == 1) {
				Folder* f = new Folder(name);
				driver.push_back(f);
			}
		}
		else if (choice == 2) {
			system("cls");
			int flag = 0;
			cout << "Cac thu muc dang co: ";
			for (auto i : driver)
				cout << i->getName() << "\t";
			cout << "\nChon thu muc muon them file: ";
			cin >> name;
			for (auto i : driver)
				if (i->getName() == name) {
					cout << "Nhap ten file: ";
					cin.ignore();
					getline(cin, name);
					float size;
					cout << "Nhap dung luong cua file: ";
					cin >> size;
					i->addNew(new File(name, size));
					flag = 1;
					break;
				}
			if (flag == 0)
				cout << "Khong tim thay thu muc!\n";
		}
		else
			cout << "ERROR!\n";
		cout << "Tiep tuc nhap? (Y/N) ";
		cin >> key;
	} while (key == 'Y' || key == 'y');
	cout << "Cac thu muc va file co trong o dia la:\n";
	for (auto i : driver) {
		cout << "Ten thu muc: " << i->getName() << endl;
		cout << "Cac file co trong thu muc: \n";
		cout << i;
	}
	float total = 0;
	for (auto i : driver)
		total += i->getSize();
	cout << "Dung luong tong cua o dia la " << total << " bytes.\n";
}